package com.demo.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class CustomerTest {

    @Test
    void customersWithSameIdAreEqual() {
        Customer first = new Customer("1", "Alice");
        Customer second = new Customer("1", "Bob");
        assertEquals(first, second);
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    void customersWithDifferentIdAreNotEqual() {
        assertNotEquals(new Customer("1", "Alice"), new Customer("2", "Alice"));
    }

    @Test
    void infoContainsName() {
        assertEquals(Map.of("name", "Alice"), new Customer("1", "Alice").getInfo());
    }

    @Test
    void emailsAreEmpty() {
        assertEquals(List.of(), new Customer("1", "Alice").getEmails());
    }
}