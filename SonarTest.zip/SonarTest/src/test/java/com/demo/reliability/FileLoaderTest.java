package com.demo.reliability;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.io.File;
import java.nio.file.Files;
import org.junit.jupiter.api.Test;

class FileLoaderTest {
    @Test
    void firstLine() throws Exception {
        File f = File.createTempFile("file", ".txt");
        f.deleteOnExit();
        Files.writeString(f.toPath(), "hello\nworld");
        assertEquals("hello", new FileLoader().firstLine(f.getAbsolutePath()));
    }

    @Test
    void waitBeforeRetryNormal() {
        FileLoader l = new FileLoader();
        l.waitBeforeRetry();
        assertEquals("idle", l.getStatus());
    }

    @Test
    void waitBeforeRetryInterrupted() {
        FileLoader l = new FileLoader();
        Thread.currentThread().interrupt();
        l.waitBeforeRetry();
        Thread.interrupted();
        assertEquals("interrupted", l.getStatus());
    }
}