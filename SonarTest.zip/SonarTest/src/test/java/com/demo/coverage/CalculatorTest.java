package com.demo.coverage;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

class CalculatorTest {

    @Test
    void diviserNormal() {
        assertEquals(5, new Calculator().diviser(10, 2));
    }

    @Test
    void diviserParZero() {
        Calculator calculator = new Calculator();
        assertThrows(IllegalArgumentException.class, () -> calculator.diviser(1, 0));
    }
}