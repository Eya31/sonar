package com.demo.security;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import org.junit.jupiter.api.Test;

class PasswordHasherTest {
    @Test
    void hashHasSaltAndDigest() {
        assertEquals(97, new PasswordHasher().hash("abc").length());
    }

    @Test
    void hashIsSalted() {
        PasswordHasher hasher = new PasswordHasher();
        assertNotEquals(hasher.hash("abc"), hasher.hash("abc"));
    }
}