package com.demo.security;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.junit.jupiter.api.Test;

class UserRepositoryTest {
    @Test
    void findIdsByName() throws Exception {
        Connection c = mock(Connection.class);
        PreparedStatement ps = mock(PreparedStatement.class);
        ResultSet rs = mock(ResultSet.class);
        when(c.prepareStatement(anyString())).thenReturn(ps);
        when(ps.executeQuery()).thenReturn(rs);
        when(rs.next()).thenReturn(true, true, false);
        when(rs.getString("id")).thenReturn("1", "2");
        assertEquals(List.of("1", "2"), new UserRepository().findIdsByName(c, "bob"));
    }

    @Test
    void connectFailsWithoutDatabase() {
        UserRepository repository = new UserRepository();
        assertThrows(SQLException.class, repository::connect);
    }
}