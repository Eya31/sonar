package com.demo.exceptions;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class PaymentServiceTest {

    private final PaymentService service = new PaymentService();

    @Test
    void payPositiveAmountDoesNotThrow() {
        assertDoesNotThrow(() -> service.pay(10));
    }

    @Test
    void payNegativeAmountThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.pay(-1));
    }

    @Test
    void tryPayReturnsTrueForValidAmount() {
        assertTrue(service.tryPay(10));
    }

    @Test
    void tryPayReturnsFalseForNegativeAmount() {
        assertFalse(service.tryPay(-1));
    }
}