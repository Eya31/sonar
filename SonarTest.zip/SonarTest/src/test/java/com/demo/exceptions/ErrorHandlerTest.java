package com.demo.exceptions;

import static org.junit.jupiter.api.Assertions.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ErrorHandlerTest {
    private final ErrorHandler handler = new ErrorHandler();

    @Test
    void parseAmount() {
        assertEquals(12, handler.parseAmount("12"));
        assertEquals(0, handler.parseAmount("abc"));
    }

    @Test
    void readLines(@TempDir Path dir) throws Exception {
        Path file = dir.resolve("a.txt");
        Files.writeString(file, "a\nb");
        assertEquals(List.of("a", "b"), handler.readLines(file.toString()));
    }

    @Test
    void readLinesMissingFile() {
        assertTrue(handler.readLines("/inexistant/fichier.txt").isEmpty());
    }
}