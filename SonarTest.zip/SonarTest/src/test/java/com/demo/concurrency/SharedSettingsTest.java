package com.demo.concurrency;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class SharedSettingsTest {
    @Test
    void registerAndLimit() {
        int before = SharedSettings.getInstances();
        SharedSettings s = new SharedSettings();
        s.register();
        assertEquals(before + 1, SharedSettings.getInstances());
        assertEquals(10, s.getLimit());
        s.setLimit(5);
        assertEquals(5, s.getLimit());
    }
}