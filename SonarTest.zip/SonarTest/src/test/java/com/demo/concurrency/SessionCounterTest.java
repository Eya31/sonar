package com.demo.concurrency;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class SessionCounterTest {
    @Test
    void increment() {
        SessionCounter c = new SessionCounter();
        c.increment();
        c.increment();
        assertEquals(2, c.getCount());
    }
}