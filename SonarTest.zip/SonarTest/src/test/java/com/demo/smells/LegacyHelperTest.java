package com.demo.smells;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class LegacyHelperTest {
    @Test
    void compute() {
        LegacyHelper h = new LegacyHelper();
        assertEquals(5, h.compute(5));
        assertEquals(0, h.compute(-1));
    }

    @Test
    void isPositive() {
        LegacyHelper h = new LegacyHelper();
        assertTrue(h.isPositive(1));
        assertFalse(h.isPositive(-1));
    }
}