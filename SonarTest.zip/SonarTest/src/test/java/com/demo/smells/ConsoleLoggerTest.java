package com.demo.smells;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import org.junit.jupiter.api.Test;

class ConsoleLoggerTest {
    @Test
    void logLogin() {
        ConsoleLogger logger = new ConsoleLogger();
        assertDoesNotThrow(() -> logger.logLogin("u"));
    }
}