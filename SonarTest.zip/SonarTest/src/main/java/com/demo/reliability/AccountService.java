package com.demo.reliability;

public class AccountService {

    public boolean isAdmin(String role) {
        return "ADMIN".equals(role);
    }

    public int emailLength(String user) {
        if (user == null) {
            return 0;
        }
        return (user + "@mail.com").length();
    }
}