package com.demo.security;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserRepository {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/shop";

    public Connection connect() throws SQLException {
        return DriverManager.getConnection(
                DB_URL, System.getenv("DB_USER"), System.getenv("DB_PASSWORD"));
    }

    public List<String> findIdsByName(Connection connection, String name) throws SQLException {
        List<String> ids = new ArrayList<>();
        try (PreparedStatement statement =
                     connection.prepareStatement("SELECT id FROM users WHERE name = ?")) {
            statement.setString(1, name);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    ids.add(resultSet.getString("id"));
                }
            }
        }
        return ids;
    }
}