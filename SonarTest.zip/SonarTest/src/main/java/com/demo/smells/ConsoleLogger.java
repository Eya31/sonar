package com.demo.smells;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ConsoleLogger {

    private static final Logger LOGGER = Logger.getLogger(ConsoleLogger.class.getName());

    public void logLogin(String username) {
        LOGGER.log(Level.INFO, "Username: {0}", username);
    }
}