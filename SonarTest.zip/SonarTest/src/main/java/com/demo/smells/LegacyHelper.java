package com.demo.smells;

public class LegacyHelper {

    public int compute(int value) {
        return Math.max(value, 0);
    }

    public boolean isPositive(int number) {
        return number > 0;
    }
}