package com.demo.coverage;

public class Calculator {

    public int diviser(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("Division par zero");
        }
        return a / b;
    }
}