package com.demo.exceptions;

public class PaymentService {

    public void pay(double amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Negative amount");
        }
    }

    public boolean tryPay(double amount) {
        try {
            pay(amount);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}