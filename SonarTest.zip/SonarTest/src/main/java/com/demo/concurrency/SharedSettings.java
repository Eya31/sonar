package com.demo.concurrency;

import java.util.concurrent.atomic.AtomicInteger;

public class SharedSettings {

    private static final AtomicInteger INSTANCES = new AtomicInteger();
    private volatile int limit = 10;

    public void register() {
        INSTANCES.incrementAndGet();
    }

    public static int getInstances() {
        return INSTANCES.get();
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }
}