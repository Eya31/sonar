package com.demo.concurrency;

import java.util.concurrent.atomic.AtomicInteger;

public class SessionCounter {

    private final AtomicInteger count = new AtomicInteger();

    public void increment() {
        count.incrementAndGet();
    }

    public int getCount() {
        return count.get();
    }
}