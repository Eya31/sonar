package com.demo.api;

import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Customer {

    private final String id;
    private final String name;

    public Customer(String id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Customer customer && Objects.equals(id, customer.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    public List<String> getEmails() {
        return List.of();
    }

    public Map<String, String> getInfo() {
        return Map.of("name", name);
    }
}