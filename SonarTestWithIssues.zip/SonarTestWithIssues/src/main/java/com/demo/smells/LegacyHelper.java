package com.demo.smells;

public class LegacyHelper {

    private int unusedCounter = 0;

    public int compute(int value) {
        int temp = value * 2;
        // TODO fix this later
        // int old = value * 3;
        // return old + 1;
        if (value > 0 && value > 0) {
            return value;
        }
        return 0;
    }

    public boolean isPositive(int number) {
        if (number > 0) {
            return true;
        } else {
            return false;
        }
    }

    private String neverCalled() {
        return "dead";
    }
}