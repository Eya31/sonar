package com.demo.smells;

public class ConsoleLogger {

    public void logLogin(String username, String password) {
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);
    }
}