package com.demo.security;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserRepository {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/shop";
    private static final String DB_PASSWORD = "root123";

    public Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL, "root", DB_PASSWORD);
    }

    public List<String> findIdsByName(Connection connection, String name) throws SQLException {
        List<String> ids = new ArrayList<>();
        String query = "SELECT id FROM users WHERE name = '" + name + "'";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                ids.add(resultSet.getString("id"));        

            }
        }
        return ids;
    }
}
/*« Les identifiants doivent être stockés dans un fichier de configuration non commité dans le dépôt,
 dans une base de données, ou gérés par le service de secrets de ton fournisseur cloud. 
 Si un mot de passe est exposé dans le code source, il doit être changé immédiatement. » */