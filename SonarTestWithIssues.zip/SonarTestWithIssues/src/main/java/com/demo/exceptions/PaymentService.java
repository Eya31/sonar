package com.demo.exceptions;

public class PaymentService {

    // PROBLEME : "throws Exception" est trop générique. L'appelant ne sait pas quelle erreur
    // traiter. Utiliser une exception précise (IllegalArgumentException ou une exception métier).
    public void pay(double amount) throws Exception {
        if (amount < 0) {
            // PROBLEME : lancer "new Exception" directement est trop vague, même raison.
            throw new Exception("Negative amount");
        }
    }

    public boolean tryPay(double amount) {
        try {
            pay(amount);
            return true;
        } catch (Throwable t) {
            // PROBLEME : attraper Throwable capture aussi les Error graves (OutOfMemoryError,
            // StackOverflowError...) qu'on ne doit jamais masquer. Attraper l'exception précise.
            return false;
        }
    }
}