package com.demo.exceptions;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;

public class ErrorHandler {

    public int parseAmount(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            // PROBLEME : bloc catch vide. L'erreur est avalée en silence, personne ne sait
            // qu'une valeur invalide est arrivée. Il faut au minimum la logger ou la commenter.
        }
        return 0;
    }

    public List<String> readLines(String path) {
        try {
            return Files.readAllLines(Path.of(path));
        } catch (IOException e) {
            // PROBLEME : printStackTrace() écrit sur la sortie d'erreur, sans niveau ni format.
            // En production, il faut un vrai logger (SLF4J, java.util.logging...).
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
}