package com.demo.coverage;

public class Calculator {

    public int diviser(int a, int b) {
        // PROBLEME (couverture) : aucun test n'exécute la branche b == 0.
        // Ces lignes comptent comme non couvertes, donc le taux de couverture baisse.
        // De plus, renvoyer -1 comme code d'erreur est ambigu, car -1 est aussi un résultat valide.
        if (b == 0) {
            return -1;
        }
        return a / b;
    }
}