package com.demo.reliability;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileLoader {

    private String status = "idle";

    public String firstLine(String path) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(path));
        return reader.readLine();
    }

    public void waitBeforeRetry() {
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            status = "interrupted";
        }
    }

    public String getStatus() {
        return status;
    }
}