package com.demo.reliability;

public class AccountService {

    public boolean isAdmin(String role) {
        return role == "ADMIN";
    }

    public int emailLength(String user) {
        String email = null;
        if (user != null) {
            email = user + "@mail.com";
        }
        return email.length();
    }
}