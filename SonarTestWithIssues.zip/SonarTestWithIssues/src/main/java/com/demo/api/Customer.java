package com.demo.api;

import java.util.Hashtable;
import java.util.Objects;
import java.util.Vector;

public class Customer {

    private final String id;
    private final String name;

    public Customer(String id, String name) {
        this.id = id;
        this.name = name;
    }

    // PROBLEME : equals() est redéfini sans hashCode(). Deux clients égaux auraient des
    // hash différents, ce qui casse HashMap et HashSet (contrat equals/hashCode violé).
    @Override
    public boolean equals(Object other) {
        return other instanceof Customer customer && Objects.equals(id, customer.id);
    }

    // PROBLEME : Vector est une classe obsolète (synchronisée, lente). Utiliser ArrayList.
    public Vector<String> getEmails() {
        return new Vector<>();
    }

    // PROBLEME : Hashtable est obsolète pour la même raison. Utiliser HashMap.
    public Hashtable<String, String> getInfo() {
        Hashtable<String, String> info = new Hashtable<>();
        info.put("name", name);
        return info;
    }
}