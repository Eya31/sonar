package com.demo.concurrency;

public class SessionCounter {

    // PROBLEME : volatile s'applique à la référence du tableau, pas à ses éléments.
    // Écrire dans history[0] n'est donc pas thread-safe malgré le mot-clé.
    private volatile int[] history = new int[10];

    // PROBLEME : champ non final utilisé comme verrou (voir ci-dessous).
    private Integer count = 0;

    public void increment() {
        // PROBLEME : on se synchronise sur "count", mais count++ crée un nouvel objet Integer.
        // Le verrou change à chaque appel, donc deux threads ne se bloquent jamais vraiment.
        // Il faut un verrou private final dédié.
        synchronized (count) {
            count++;
        }
        // PROBLEME : history[0]++ n'est pas atomique (lecture, ajout, écriture)
        // et n'est pas protégé : les incréments peuvent se perdre entre threads.
        history[0]++;
    }

    public int getCount() {
        return count;
    }
}