package com.demo.concurrency;

public class SharedSettings {

    private static int instances = 0;
    private int limit = 10;

    public void register() {
        // PROBLEME : une méthode d'instance modifie un champ static. Tous les objets
        // partagent ce champ, donc plusieurs threads peuvent écraser la valeur (non thread-safe).
        instances++;
    }

    public static int getInstances() {
        return instances;
    }

    // PROBLEME : le getter est synchronized mais pas le setter. Il faut synchroniser
    // les deux, sinon un thread peut lire une valeur incohérente pendant une écriture.
    public synchronized int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }
}