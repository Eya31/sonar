package com.demo.api;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class CustomerTest {
    @Test
    void equalsAndOthers() {
        Customer a = new Customer("1", "a");
        assertEquals(a, new Customer("1", "b"));
        assertNotEquals(a, new Customer("2", "a"));
        assertNotEquals(a, "x");
        assertTrue(a.getEmails().isEmpty());
        assertEquals("a", a.getInfo().get("name"));
    }
}