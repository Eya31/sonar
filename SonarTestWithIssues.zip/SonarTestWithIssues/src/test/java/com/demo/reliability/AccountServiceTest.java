package com.demo.reliability;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class AccountServiceTest {
    @Test
    void emailLengthForKnownUser() {
        assertEquals(12, new AccountService().emailLength("eya"));
    }

    @Test
    void emailLengthNullThrows() {
        assertThrows(NullPointerException.class, () -> new AccountService().emailLength(null));
    }

    @Test
    void isAdmin() {
        assertTrue(new AccountService().isAdmin("ADMIN"));
        assertFalse(new AccountService().isAdmin("USER"));
    }
}