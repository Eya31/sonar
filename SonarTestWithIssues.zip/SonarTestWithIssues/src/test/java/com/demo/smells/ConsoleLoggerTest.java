package com.demo.smells;

import static org.junit.jupiter.api.Assertions.assertTrue;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.jupiter.api.Test;

class ConsoleLoggerTest {
    @Test
    void logLogin() {
        PrintStream old = System.out;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));
        try {
            new ConsoleLogger().logLogin("u", "p");
        } finally {
            System.setOut(old);
        }
        assertTrue(out.toString().contains("Username: u"));
    }
}