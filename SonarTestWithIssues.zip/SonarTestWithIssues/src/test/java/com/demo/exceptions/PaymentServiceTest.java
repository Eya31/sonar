package com.demo.exceptions;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class PaymentServiceTest {
    @Test
    void payNegativeThrows() {
        assertThrows(Exception.class, () -> new PaymentService().pay(-1));
    }

    @Test
    void payPositiveOk() throws Exception {
        new PaymentService().pay(10);
    }

    @Test
    void tryPay() {
        PaymentService s = new PaymentService();
        assertTrue(s.tryPay(10));
        assertFalse(s.tryPay(-1));
    }
}