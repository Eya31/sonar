package com.demo.coverage;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class CalculatorTest {

    @Test
    void diviserNormal() {
        assertEquals(5, new Calculator().diviser(10, 2));
    }
}