package com.demo.security;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import org.junit.jupiter.api.Test;

class UserRepositoryTest {
    @Test
    void findIdsByName() throws Exception {
        Connection c = mock(Connection.class);
        Statement st = mock(Statement.class);
        ResultSet rs = mock(ResultSet.class);
        when(c.createStatement()).thenReturn(st);
        when(st.executeQuery(anyString())).thenReturn(rs);
        when(rs.next()).thenReturn(true, true, false);
        when(rs.getString("id")).thenReturn("1", "2");
        assertEquals(List.of("1", "2"), new UserRepository().findIdsByName(c, "bob"));
    }

    @Test
    void connectFailsWithoutDatabase() {
        assertThrows(SQLException.class, () -> new UserRepository().connect());
    }
}