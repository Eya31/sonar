package com.demo.security;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class PasswordHasherTest {
    @Test
    void hashRuns() {
        assertEquals("900150983cd24fb0d6963f7d28e17f72", new PasswordHasher().hash("abc"));
    }

    @Test
    void hashLength() {
        assertEquals(32, new PasswordHasher().hash("abcdef").length());
    }
}